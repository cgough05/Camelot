// footer.js
function loadFooter() {
    var footerContainer = document.getElementById("footer-container");
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            footerContainer.innerHTML = this.responseText;
        }
    };
    xhttp.open("GET", "footer.html", true);
    xhttp.send();
}

window.addEventListener("DOMContentLoaded", loadFooter);
