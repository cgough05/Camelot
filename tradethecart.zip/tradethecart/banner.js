// banner.js
function loadBanner() {
    var bannerContainer = document.getElementById("banner-container");
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            bannerContainer.innerHTML = this.responseText;
        }
    };
    xhttp.open("GET", "banner.html", true);
    xhttp.send();
}

window.addEventListener("DOMContentLoaded", loadBanner);

