document.getElementById('filter-form').addEventListener('submit', function(e) {
    e.preventDefault();

    const filters = {
        type: document.getElementById('type').value
        // Add other filters here
    };

    fetchData(filters);
});

function fetchData(filters) {
    const queryString = new URLSearchParams(filters).toString();
    fetch(`http://localhost:3000/collections?${queryString}`)
        .then(response => response.json())
        .then(data => displayCards(data))
        .catch(error => console.error('Error:', error));
}

function displayCards(cards) {
    const resultsContainer = document.getElementById('results-container');
    resultsContainer.innerHTML = '';
    cards.forEach(card => {
        const cardDiv = document.createElement('div');
        cardDiv.innerHTML = `<h5>${card.name}</h5><p>Type: ${card.type}</p>`; // Adjust according to your data
        resultsContainer.appendChild(cardDiv);
    });
}
