const express = require('express');
const mysql = require('mysql');
const cors = require('cors');
const bcrypt = require('bcrypt');

// Create an instance of Express
const app = express();

// Enable CORS for all routes
app.use(cors());

// Parse JSON bodies (as sent by API clients)
app.use(express.json());

// Create a connection to your MySQL database
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'Gr33nval31633!', // Reminder: Be cautious with passwords in code!
    database: 'pokemon_cards'
});

// Connect to the MySQL database
db.connect(err => {
    if (err) {
        console.error('Error connecting to MySQL database:', err);
        return;
    }
    console.log('Connected to MySQL database');
});

app.get('/collections', (req, res) => {
    let query = 'SELECT * FROM cards';
    const params = [];

    // Check for filter parameters and adjust the query
    if (req.query.type) {
        query += ' WHERE type = ?';
        params.push(req.query.type);
    }

    // Add more conditions based on other filters (rarity, etc.)

    db.query(query, params, (err, results) => {
        if (err) {
            console.error('Database query error:', err);
            res.status(500).send('Error retrieving data from database');
            return;
        }
        res.json(results);
    });
});


// Endpoint for user registration
app.post('/register', async (req, res) => {
    const { username, password, email } = req.body;

    try {
        const hashedPassword = await bcrypt.hash(password, 10);

        const query = 'INSERT INTO users (username, password, email) VALUES (?, ?, ?)';
        db.query(query, [username, hashedPassword, email], (err, result) => {
            if (err) {
                console.error('Database query error:', err);
                res.status(500).send('Error registering new user');
                return;
            }
            res.status(201).send('User registered successfully');
        });
    } catch (err) {
        console.error('Error during registration:', err);
        res.status(500).send('Internal Server Error');
    }
});

// Endpoint for user login
app.post('/login', (req, res) => {
    const { username, password } = req.body;

    const query = 'SELECT * FROM users WHERE username = ?';
    db.query(query, [username], async (err, results) => {
        if (err) {
            console.error('Database query error:', err);
            res.status(500).send('Error logging in');
            return;
        }

        if (results.length > 0) {
            const match = await bcrypt.compare(password, results[0].password);
            if (match) {
                res.send('Logged in successfully');
            } else {
                res.status(401).send('Incorrect password');
            }
        } else {
            res.status(404).send('User not found');
        }
    });
});

// Endpoint to fetch user profile data
app.get('/api/user/profile/:userId', (req, res) => {
    const userId = req.params.userId;

    const query = 'SELECT username, email, created_at FROM users WHERE user_id = ?';

    db.query(query, [userId], (error, results) => {
        if (error) {
            console.error('Database query error:', error);
            res.status(500).send('Error fetching user data');
            return;
        }

        if (results.length > 0) {
            // Remove sensitive fields like password before sending the data
            delete results[0].password;
            res.json(results[0]);
        } else {
            res.status(404).send('User not found');
        }
    });
});

// Start the server on port 3000
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
